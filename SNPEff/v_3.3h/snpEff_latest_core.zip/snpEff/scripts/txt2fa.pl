#!/usr/bin/perl

for( $i=1 ; $l = <STDIN> ; $i++ ) { print ">id_$i\n$l"; }
